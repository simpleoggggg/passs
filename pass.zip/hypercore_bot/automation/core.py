from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import traceback
import time
import pycountry
from automation.driver import create_driver

all_countries = {country.name for country in pycountry.countries}

def scrape_account_info(email: str, password: str, progress_fn=None) -> dict:
    driver = create_driver()
    wait = WebDriverWait(driver, 20)

    # ── FIX: was calling itself recursively (infinite loop) ──────────────────
    def log(msg):
        print(msg)
        if progress_fn:
            try:
                progress_fn(msg)
            except Exception:
                pass

    try:
        # ── EMAIL ─────────────────────────────────────────────────────────────
        log(f"🌐 Opening Microsoft login for {email}...")
        driver.get("https://login.live.com")

        try:
            email_input = WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.ID, "usernameEntry"))
            )
        except TimeoutException:
            # Some regions show a different login URL
            driver.get("https://account.microsoft.com")
            email_input = WebDriverWait(driver, 15).until(
                EC.presence_of_element_located((By.ID, "usernameEntry"))
            )

        email_input.clear()
        email_input.send_keys(email)
        email_input.send_keys(Keys.RETURN)
        time.sleep(2)
        log("📧 Email submitted.")

        # ── PASSWORD — try every known UI variant ─────────────────────────────
        password_input = None

        # Variant 1: direct passwd field
        try:
            password_input = WebDriverWait(driver, 4).until(
                EC.presence_of_element_located((By.NAME, "passwd"))
            )
            log("✅ Password field appeared directly.")
        except TimeoutException:
            pass

        # Variant 2: "Use your password" button
        if not password_input:
            try:
                btn = WebDriverWait(driver, 4).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//*[contains(text(),'Use your password') or contains(text(),'use your password')]"
                    ))
                )
                btn.click()
                log("➡️ Clicked 'Use your password'")
                password_input = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                pass

        # Variant 3: "Other ways to sign in" → "Use your password"
        if not password_input:
            try:
                btn = WebDriverWait(driver, 4).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//*[contains(text(),'Other ways to sign in')]"
                    ))
                )
                btn.click()
                log("➡️ Clicked 'Other ways to sign in'")
                time.sleep(1)
                btn2 = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//*[contains(text(),'Use your password')]"
                    ))
                )
                btn2.click()
                log("➡️ Clicked 'Use your password'")
                password_input = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                pass

        # Variant 4: legacy switch link
        if not password_input:
            try:
                link = WebDriverWait(driver, 4).until(
                    EC.element_to_be_clickable((By.ID, "idA_PWD_SwitchToCredPicker"))
                )
                link.click()
                log("➡️ Clicked legacy 'Sign in another way'")
                time.sleep(1)
                btn = WebDriverWait(driver, 5).until(
                    EC.element_to_be_clickable((By.XPATH,
                        "//*[contains(text(),'Use your password')]"
                    ))
                )
                btn.click()
                password_input = WebDriverWait(driver, 5).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                pass

        # Variant 5: passwordEntry id (newer UI)
        if not password_input:
            try:
                password_input = WebDriverWait(driver, 4).until(
                    EC.presence_of_element_located((By.ID, "passwordEntry"))
                )
                log("✅ Found passwordEntry field.")
            except TimeoutException:
                pass

        if not password_input:
            log(f"❌ Could not find password field. Page title: {driver.title}")
            log(f"   Current URL: {driver.current_url}")
            return {"email": email, "error": f"Could not reach password field. Page: {driver.title}"}

        # ── SUBMIT PASSWORD ───────────────────────────────────────────────────
        password_input.clear()
        password_input.send_keys(password)
        password_input.send_keys(Keys.RETURN)
        time.sleep(2)
        log("🔑 Password submitted.")

        # ── CHECK FOR WRONG PASSWORD ──────────────────────────────────────────
        try:
            err_el = driver.find_element(By.ID, "passwordError")
            if err_el.is_displayed() and err_el.text.strip():
                log(f"❌ Wrong password: {err_el.text.strip()}")
                return {"email": email, "error": f"Incorrect password: {err_el.text.strip()}"}
        except NoSuchElementException:
            pass

        try:
            still_visible = driver.find_element(By.ID, "passwordEntry")
            if still_visible.is_displayed():
                log("❌ Password field still shown — password likely incorrect.")
                return {"email": email, "error": "Incorrect password"}
        except NoSuchElementException:
            log("✅ Password accepted, moving on.")

        # ── RATE LIMIT ────────────────────────────────────────────────────────
        if "Too Many Requests" in driver.page_source:
            log("⚠️ Rate limited — waiting up to 20s...")
            for _ in range(20):
                time.sleep(1)
                driver.refresh()
                if "Too Many Requests" not in driver.page_source:
                    break
            else:
                return {"email": email, "error": "Rate limited by Microsoft"}

        # ── POST-LOGIN PROMPTS ────────────────────────────────────────────────
        # "Protect your account" / security update screen
        try:
            WebDriverWait(driver, 4).until(
                EC.element_to_be_clickable((By.ID, "iLandingViewAction"))
            ).click()
            log("🔒 Dismissed security update prompt.")
            time.sleep(2)
        except TimeoutException:
            pass

        # "Stay signed in?" — click Yes if present, otherwise just continue
        try:
            WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, 'button[data-testid="primaryButton"]'))
            ).click()
            log("✅ Confirmed 'Stay signed in'.")
            time.sleep(2)
        except TimeoutException:
            log("ℹ️ No 'Stay signed in' prompt — continuing.")

        # Security / close modal
        try:
            WebDriverWait(driver, 4).until(
                EC.element_to_be_clickable((By.XPATH, '//button[@aria-label="Close"]'))
            ).click()
            log("🛡️ Closed security modal.")
            time.sleep(1)
        except TimeoutException:
            pass

        # ── PROFILE PAGE ──────────────────────────────────────────────────────
        log("🌐 Loading Microsoft profile page...")
        driver.get("https://account.microsoft.com/profile")
        time.sleep(3)

        name = "Unknown"
        dob  = "DOB not found"
        region = "Region not found"

        try:
            # Wait for page — try multiple known name element IDs
            name_found = False
            for name_id in ["profile.profile-page.personal-section.full-name", "mectrl_currentAccountPersonalInfo"]:
                try:
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, name_id)))
                    name = driver.find_element(By.ID, name_id).text.strip()
                    if name:
                        name_found = True
                        break
                except Exception:
                    pass
            if not name_found:
                for sel in ['h1', 'h2', '[data-testid*="name"]']:
                    try:
                        t = driver.find_element(By.CSS_SELECTOR, sel).text.strip()
                        if t: name = t; break
                    except Exception:
                        pass
            log(f"🔹 Name: {name}")

            # DOB — multiple selectors + regex scan
            import re as _re
            for span in driver.find_elements(By.CSS_SELECTOR, 'span.fui-Text, span[class*="Text"], [data-testid*="dob"]'):
                text = span.text.strip()
                if _re.match(r"\d{1,2}[/\-]\d{1,2}[/\-]\d{4}", text) and dob == "DOB not found":
                    dob = text
                    log(f"🔹 DOB: {dob}")
                if text in all_countries and region == "Region not found":
                    region = text
                    log(f"🔹 Region: {region}")

            # DOB fallback — aria-label scan
            if dob == "DOB not found":
                for el in driver.find_elements(By.XPATH, '//*[contains(@aria-label,"birth") or contains(@aria-label,"Birth")]'):
                    t = (el.text or el.get_attribute("value") or "").strip()
                    m = _re.search(r"\d{1,2}[/\-]\d{1,2}[/\-]\d{4}", t)
                    if m:
                        dob = m.group(); log(f"🔹 DOB (aria): {dob}"); break

            # DOB fallback — page source regex
            if dob == "DOB not found":
                m = _re.search(r"(\d{1,2}/\d{1,2}/\d{4})", driver.page_source)
                if m: dob = m.group(1); log(f"🔹 DOB (source): {dob}")

            # Region fallback — aria-label scan
            if region == "Region not found":
                for el in driver.find_elements(By.XPATH, '//*[contains(@aria-label,"country") or contains(@aria-label,"Country") or contains(@aria-label,"region")]'):
                    t = (el.text or el.get_attribute("value") or "").strip()
                    if t in all_countries:
                        region = t; log(f"🔹 Region (aria): {region}"); break

            if dob == "DOB not found":
                log("⚠️ DOB not found — ACSR will abort early to avoid rejection")
            if region == "Region not found":
                log("⚠️ Region not found — ACSR will abort early to avoid rejection")

        except Exception as e:
            log(f"⚠️ Profile scrape issue: {e}")

        # ── SKYPE ─────────────────────────────────────────────────────────────
        skype_id    = f"live:{email.split('@')[0]}"
        skype_email = email
        try:
            driver.get("https://secure.skype.com/portal/profile")
            time.sleep(3)
            skype_id = driver.find_element(By.CLASS_NAME, "username").text.strip() or skype_id
            log(f"🔹 Skype ID: {skype_id}")
        except Exception:
            log(f"ℹ️ Skype ID not found — using fallback: {skype_id}")
        try:
            skype_email = driver.find_element(By.ID, "email1").get_attribute("value").strip() or email
        except Exception:
            pass

        # ── XBOX GAMERTAG ─────────────────────────────────────────────────────
        gamertag = "Not found"
        try:
            driver.get("https://www.xbox.com/en-US/play/user")
            time.sleep(5)
            try:
                driver.find_element(By.XPATH, '//a[contains(text(), "Sign in")]').click()
                time.sleep(7)
            except Exception:
                pass
            try:
                WebDriverWait(driver, 6).until(
                    EC.element_to_be_clickable((By.XPATH, '//span[@role="button"]'))
                ).click()
                WebDriverWait(driver, 15).until(EC.url_contains("/play/user/"))
            except Exception:
                pass
            url = driver.current_url
            if "/play/user/" in url:
                gamertag = url.split("/play/user/")[-1].replace("%20", " ").replace("%25", "%")
                log(f"🔹 Gamertag: {gamertag}")
        except Exception:
            log("ℹ️ Gamertag not found.")

        log("✅ All account info collected successfully!")
        return {
            "email":       email,
            "password":    password,
            "name":        name,
            "dob":         dob,
            "region":      region,
            "skype_id":    skype_id,
            "skype_email": skype_email,
            "gamertag":    gamertag
        }

    except Exception as e:
        err_detail = traceback.format_exc()
        log(f"❌ Login failed with exception: {e}")
        log(f"   Traceback: {err_detail}")
        return {"email": email, "error": f"Login error: {str(e)}"}

    finally:
        try:
            driver.quit()
        except Exception:
            pass
