from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from tempmail import get_otp_from_first_email, wait_for_emails, read_message, extract_specific_link, get_messages
from datetime import datetime
from automation.captcha import download_captcha
import os
import time

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# FIX: Handles ALL date formats, never silently falls back to wrong date
def parse_dob(date_str):
    if not date_str or date_str in ("DOB not found", "Not found", "", "N/A"):
        raise ValueError(f"DOB missing: '{date_str}'")
    formats = ["%m/%d/%Y", "%d/%m/%Y", "%Y-%m-%d", "%B %d, %Y", "%b %d, %Y", "%d %B %Y", "%d-%m-%Y", "%m-%d-%Y"]
    for fmt in formats:
        try:
            dt = datetime.strptime(date_str.strip(), fmt)
            return dt.strftime("%B"), str(dt.day), str(dt.year)
        except ValueError:
            continue
    raise ValueError(f"Cannot parse DOB: '{date_str}'")

def _safe_select(el, text, fallbacks=None):
    for val in [text] + (fallbacks or []):
        try:
            Select(el).select_by_visible_text(val)
            return True
        except Exception:
            pass
    try:
        Select(el).select_by_value(text)
        return True
    except Exception:
        pass
    return False

def _click_submit(driver, wait, timeout=8):
    """Try every known submit/next button variant, then JS fallback."""
    selectors = [
        (By.ID,          "NextButton"),
        (By.ID,          "iNext"),
        (By.ID,          "idSIButton9"),
        (By.ID,          "iSelectProofAction"),
        (By.CSS_SELECTOR,'input[type="submit"]'),
        (By.CSS_SELECTOR,'button[type="submit"]'),
        (By.XPATH,       '//input[@value="Next" or @value="Submit" or @value="Continue"]'),
        (By.XPATH,       '//button[contains(text(),"Next") or contains(text(),"Submit") or contains(text(),"Continue")]'),
    ]
    for by, sel in selectors:
        try:
            btn = WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((by, sel)))
            btn.click()
            return True
        except Exception:
            pass
    # JS fallback — always works even if button is hidden
    try:
        driver.execute_script("document.querySelector('form').submit();")
        return True
    except Exception:
        pass
    return False

def _wait_page(driver, old_url, el_checks, timeout=15):
    """Wait until URL changes OR an expected element appears on new page."""
    for _ in range(timeout):
        time.sleep(1)
        if driver.current_url != old_url:
            time.sleep(1)
            return True
        for by, sel in el_checks:
            try:
                driver.find_element(by, sel)
                return True
            except Exception:
                pass
    return False


def continue_acsr_flow(driver, account_info, token, captcha_text, user_id, progress_fn=None):
    wait = WebDriverWait(driver, 20)

    def log(msg):
        print(msg)
        if progress_fn:
            try: progress_fn(msg)
            except Exception: pass

    # ── Pre-flight validation — abort early if data is bad ────────────────────
    dob_raw     = account_info.get("dob", "")
    region_raw  = account_info.get("region", "")
    gamertag    = account_info.get("gamertag", "Not found")
    skype_id    = account_info.get("skype_id", "")
    skype_email = account_info.get("skype_email", account_info.get("email", ""))
    name        = account_info.get("name", "").strip()
    password    = account_info.get("password", "")

    # FIX: DOB — abort instead of submitting wrong date
    try:
        month, day, year = parse_dob(dob_raw)
        log(f"📅 DOB parsed: {month} {day}, {year}")
    except ValueError as e:
        log(f"❌ {e} — aborting to avoid rejection.")
        try: driver.quit()
        except: pass
        return "ACSR_REJECTED"

    # FIX: Region — abort if missing
    if region_raw in ("Region not found", "Not found", "", "N/A", None):
        log(f"❌ Region missing — aborting to avoid rejection.")
        try: driver.quit()
        except: pass
        return "ACSR_REJECTED"

    # Clean Skype ID
    if not skype_id:
        skype_id = f"live:{account_info.get('email','').split('@')[0]}"
    if not skype_email:
        skype_email = account_info.get("email", "")

    has_gamertag = gamertag not in ("Not found", "", "N/A", None)
    first, last  = (name.split(maxsplit=1) if " " in name else (name or "Unknown", "User"))

    try:
        # ── CAPTCHA ──────────────────────────────────────────────────────────
        try:
            captcha_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[contains(@id,"SolutionElement")]'))
            )
            captcha_input.clear()
            captcha_input.send_keys(captcha_text)
            captcha_input.send_keys(Keys.RETURN)
            log("📨 CAPTCHA submitted — waiting for OTP field...")
            WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "iOttText")))
            log("✅ CAPTCHA accepted!")
        except Exception:
            log("❌ CAPTCHA incorrect — fetching new image...")
            try:
                img = download_captcha(driver)
                with open(os.path.join(BASE_DIR, f"captcha_retry_{user_id}.png"), "wb") as f:
                    f.write(img.read())
                return "CAPTCHA_RETRY_NEEDED"
            except Exception as e:
                log(f"❌ Could not download new CAPTCHA: {e}")
                return "CAPTCHA_DOWNLOAD_FAILED"

        # ── OTP ───────────────────────────────────────────────────────────────
        log("⌛ Waiting for OTP from temp email...")
        otp = get_otp_from_first_email(token)
        if not otp:
            log("❌ OTP not received from temp mail.")
            return "NO_MAIL_RECEIVED"   # FIX: was returning raw string that bypassed error checks

        log(f"📥 OTP received: `{otp}`")
        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(otp)
        code_input.send_keys(Keys.RETURN)
        log("🔐 OTP submitted.")
        time.sleep(2)

        # ── NAME ──────────────────────────────────────────────────────────────
        log(f"🧾 Filling name: **{first} {last}**")
        fe = wait.until(EC.presence_of_element_located((By.ID, "FirstNameInput")))
        fe.clear(); fe.send_keys(first)
        le = wait.until(EC.presence_of_element_located((By.ID, "LastNameInput")))
        le.clear(); le.send_keys(last)
        time.sleep(0.3)

        # ── DOB ───────────────────────────────────────────────────────────────
        day_el = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "BirthDate_dayInput")))
        _safe_select(day_el, day, [day.zfill(2), f" {day}"])
        month_el = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "BirthDate_monthInput")))
        _safe_select(month_el, month)
        year_el = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.ID, "BirthDate_yearInput")))
        _safe_select(year_el, year)
        log(f"📆 DOB filled: **{month} {day}, {year}**")

        # ── REGION/COUNTRY ────────────────────────────────────────────────────
        log(f"🌍 Filling region: **{region_raw}**")
        country_el = wait.until(EC.presence_of_element_located((By.ID, "CountryInput")))
        if country_el.tag_name.lower() == "select":
            # FIX: properly select from dropdown instead of just send_keys
            ok = _safe_select(country_el, region_raw)
            if not ok:
                _safe_select(country_el, region_raw.split()[0])
            log(f"🌍 Country selected from dropdown.")
        else:
            country_el.clear()
            country_el.send_keys(region_raw)
            time.sleep(1.5)
            try:
                sug = WebDriverWait(driver, 4).until(EC.element_to_be_clickable((By.CSS_SELECTOR,
                    "ul[role='listbox'] li, .autocomplete-suggestion, [data-automationid='ListCell']")))
                sug.click()
                log("🌍 Country autocomplete selected.")
            except Exception:
                country_el.send_keys(Keys.TAB)
                log("🌍 Country typed.")
        time.sleep(0.5)

        # ── SUBMIT PERSONAL INFO PAGE ─────────────────────────────────────────
        # FIX: use proper button click + JS fallback, NOT send_keys RETURN on a field
        pre_url = driver.current_url
        log("➡️ Submitting personal info page...")
        _click_submit(driver, wait)
        _wait_page(driver, pre_url, [
            (By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'),
            (By.CSS_SELECTOR, 'input[type="password"]'),
        ])
        time.sleep(1)

        # ── OLD PASSWORD — always re-find after page nav ───────────────────────
        # FIX: never reuse element refs across page navigations (stale element crash)
        log("🔑 Entering old password...")
        prev_pass = None
        for pw_sel in [
            (By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'),
            (By.ID,           "PreviousPasswordInput"),
            (By.CSS_SELECTOR, 'input[type="password"]'),
            (By.XPATH,        '//input[@type="password"]'),
        ]:
            try:
                prev_pass = WebDriverWait(driver, 8).until(EC.presence_of_element_located(pw_sel))
                break
            except Exception:
                pass

        if not prev_pass:
            log("❌ Password field not found — aborting.")
            return "ACSR_REJECTED"

        prev_pass.clear()
        prev_pass.send_keys(password)
        log("✅ Old password entered.")
        time.sleep(1)

        # ── SKYPE CHECKBOX ────────────────────────────────────────────────────
        try:
            cb = driver.find_element(By.ID, "ProductOptionSkype")
            if not cb.is_selected(): cb.click()
            log("☑️ Skype selected.")
        except Exception:
            log("⚠️ Skype checkbox not found.")

        # ── XBOX CHECKBOX ─────────────────────────────────────────────────────
        if has_gamertag:
            try:
                cb = driver.find_element(By.ID, "ProductOptionXbox")
                if not cb.is_selected(): cb.click()
                log("🎮 Xbox selected.")
            except Exception:
                log("⚠️ Xbox checkbox not found.")
        else:
            log("⏭️ Skipping Xbox (no gamertag).")

        # ── SUBMIT PASSWORD PAGE ──────────────────────────────────────────────
        pre_url = driver.current_url
        log("➡️ Submitting password page...")
        _click_submit(driver, wait)
        _wait_page(driver, pre_url, [(By.ID, "SkypeNameInput"), (By.ID, "XboxOneOption")])
        time.sleep(1)

        # ── SKYPE INFO ────────────────────────────────────────────────────────
        try:
            skype_val = skype_id if skype_id.startswith("live:") else f"live:{skype_id}"
            sn = WebDriverWait(driver, 8).until(EC.presence_of_element_located((By.ID, "SkypeNameInput")))
            sn.clear(); sn.send_keys(skype_val)
            se = WebDriverWait(driver, 8).until(EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput")))
            se.clear(); se.send_keys(skype_email)
            log(f"🔑 Skype filled: `{skype_val}`")
            time.sleep(1)
            pre_url = driver.current_url
            _click_submit(driver, wait)
            _wait_page(driver, pre_url, [(By.ID, "XboxOneOption"), (By.ID, "XboxGamertagInput")])
            time.sleep(1)
        except Exception as e:
            log(f"⚠️ Skype section skipped: {e}")

        # ── XBOX SECTION ──────────────────────────────────────────────────────
        if has_gamertag:
            try:
                log("🎮 Selecting Xbox One...")
                xbox_radio = WebDriverWait(driver, 8).until(EC.presence_of_element_located((By.ID, "XboxOneOption")))
                if not xbox_radio.is_selected(): xbox_radio.click()
                log("✅ Xbox One selected.")
                time.sleep(1)
                pre_url = driver.current_url
                _click_submit(driver, wait)
                _wait_page(driver, pre_url, [(By.ID, "XboxGamertagInput")])
                time.sleep(1)

                log(f"🎮 Entering Gamertag: `{gamertag}`")
                gt = WebDriverWait(driver, 8).until(EC.presence_of_element_located((By.ID, "XboxGamertagInput")))
                gt.clear(); gt.send_keys(gamertag)
                time.sleep(0.5)
                pre_url = driver.current_url
                _click_submit(driver, wait)
                log("✅ Gamertag submitted.")
                time.sleep(2)
            except Exception as e:
                log(f"⚠️ Xbox section skipped: {e}")

        # ── WAIT FOR RESET EMAIL ──────────────────────────────────────────────
        SUCCESS_SUBJECTS = ["your account is verified", "reset your password", "verified and now you just need"]
        REJECT_SUBJECTS  = ["your account recovery request", "information you provided was not sufficient", "donotedit"]
        SKIP_SUBJECTS    = ["personal microsoft account security code", "microsoft account security code", "security code", "verification code", "confirm your"]

        def is_success(s): return any(k in s.lower() for k in SUCCESS_SUBJECTS)
        def is_reject(s):  return any(k in s.lower() for k in REJECT_SUBJECTS)
        def is_skip(s):    return any(k in s.lower() for k in SKIP_SUBJECTS)

        log("📬 Waiting for Microsoft reset email (up to 3 min)...")
        resetlink = None
        rejected_count = 0
        seen_ids = set()

        for attempt in range(18):
            time.sleep(10)
            log(f"📨 Checking inbox... attempt **{attempt + 1}/18**")
            try:
                emails = get_messages(token)
            except Exception as e:
                log(f"⚠️ Inbox fetch failed: {e}")
                continue

            new_emails = [e for e in emails if e.get('id') not in seen_ids]
            if not new_emails:
                log("📭 No new emails yet — waiting...")
                continue

            log(f"📬 Found **{len(new_emails)}** new email(s)")
            for em in new_emails:
                subject  = em.get('subject', '')
                email_id = em.get('id')
                seen_ids.add(email_id)

                if is_skip(subject):
                    log(f"📧 Skipping OTP email: **{subject}**")
                    continue

                log(f"📧 Checking: **{subject}**")

                if is_reject(subject):
                    rejected_count += 1
                    log(f"   ❌ REJECTED by Microsoft (#{rejected_count})")
                    continue

                if not is_success(subject):
                    log(f"   ⚠️ Unknown subject — skipping")
                    continue

                log("   ✅ Success email found! Extracting link...")
                try:
                    msg  = read_message(token, email_id)
                    body = msg.get('html', '') or msg.get('text', '') or ''
                    link = extract_specific_link(body)
                    if link:
                        resetlink = link
                        log("   🔗 Reset link extracted!")
                        break
                    else:
                        log("   ⚠️ Link not found in email — retrying.")
                except Exception as e:
                    log(f"   ⚠️ Error reading email: {e}")

            if resetlink:
                break
            if rejected_count:
                log(f"⏳ {rejected_count} rejection(s) — still waiting...")

        try: driver.quit()
        except Exception: pass

        if resetlink:
            log("🔗 Reset link ready — starting password reset...")
            return resetlink
        elif rejected_count > 0:
            log("❌ ACSR None — Microsoft rejected the recovery.")
            return "ACSR_REJECTED"
        else:
            log("❌ No reset email received — check your VPN / temp mail.")
            return "NO_MAIL_RECEIVED"

    except Exception as e:
        log(f"❌ Error during ACSR flow: {e}")
        try: driver.quit()
        except: pass
        return None
